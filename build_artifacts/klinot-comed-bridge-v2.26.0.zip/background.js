const DEFAULT_API = "https://doktor-hasta-gorusmesi.onrender.com";
const COMED_HOST = "goztepetest.comed.mlpcare.com";
const PENDING_COMED_KEY = "pendingComedNavigation";

/* Eklenti guncellendiginde acik sekmelerdeki content script'ler sahipsiz
   kalir. Doktora "sayfayi yenileyin" dedirtmemek icin KLINOT PANELI
   sekmelerini kendimiz yeniliyoruz.

   COMED sekmeleri BILEREK yenilenmez: doldurulmus bir muayene formu varsa
   tarayici "siteden ayrilmak istiyor musunuz?" diye soruyor ve doktorun
   kaydedilmemis verisi riske giriyor. COMED tarafindaki kopru zaten doktorun
   bir sonraki sayfa gecisinde kendiliginden toparliyor. */
const BRIDGE_PANEL_PAGES = [
  "https://doktor-hasta-gorusmesi.onrender.com/*",
  "http://127.0.0.1:8000/*",
  "http://localhost:8000/*",
];

chrome.runtime.onInstalled.addListener(async () => {
  try {
    const tabs = await chrome.tabs.query({url: BRIDGE_PANEL_PAGES});
    for (const tab of tabs) {
      chrome.tabs.reload(tab.id, {bypassCache: false}).catch(() => {});
    }
  } catch (_) {
    // Sekme erisimi yoksa sessiz gec; kopru bir sonraki yenilemede toparlar.
  }
});

function parsedUrl(value) {
  try { return new URL(value); } catch (_) { return null; }
}

function isComedUrl(value) {
  return parsedUrl(value)?.hostname === COMED_HOST;
}

function isComedAuthUrl(value) {
  const url = parsedUrl(value);
  return url?.hostname === COMED_HOST && /\/auth\/?$/i.test(url.pathname);
}

function sameComedTarget(first, second) {
  const left = parsedUrl(first);
  const right = parsedUrl(second);
  if (!left || !right) return false;
  const path = (url) => url.pathname.replace(/\/+$/, "") || "/";
  return left.origin === right.origin && path(left) === path(right)
    && left.search === right.search;
}

async function sessionGet(key) {
  return (await chrome.storage.session.get(key))[key] || null;
}

async function sessionSet(key, value) {
  await chrome.storage.session.set({[key]: value});
}

async function sessionRemove(key) {
  await chrome.storage.session.remove(key);
}

async function openComedTarget(rawUrl, sender) {
  const target = parsedUrl(rawUrl);
  if (!target || target.hostname !== COMED_HOST || !/^https?:$/.test(target.protocol)) {
    throw new Error("Geçersiz COMED hasta kartı adresi");
  }

  const allTabs = await chrome.tabs.query({});
  const comedTabs = allTabs.filter((tab) => isComedUrl(tab.url));
  const sameWindow = comedTabs.filter((tab) => tab.windowId === sender?.tab?.windowId);
  const candidates = sameWindow.length ? sameWindow : comedTabs;
  const tab = candidates.sort((a, b) => {
    const score = (item) => item.url === target.href ? 3 : isComedAuthUrl(item.url) ? 1 : 2;
    return score(b) - score(a) || Number(b.active) - Number(a.active)
      || (b.lastAccessed || 0) - (a.lastAccessed || 0);
  })[0];

  let selected;
  if (tab) {
    await sessionSet(PENDING_COMED_KEY, {
      tabId: tab.id,
      url: target.href,
      createdAt: Date.now(),
    });
    selected = await chrome.tabs.update(tab.id, {
      active: true,
      ...(sameComedTarget(tab.url, target.href) ? {} : {url: target.href}),
    });
    await chrome.windows.update(tab.windowId, {focused: true}).catch(() => {});
    if (sameComedTarget(tab.url, target.href)) await sessionRemove(PENDING_COMED_KEY);
  } else {
    // Dogrudan hedef adresle ac. Onceden "about:blank" acilip ardindan
    // yonlendiriliyordu; ikinci adim basarisiz olursa doktorun onunde BOS
    // bir sekme kaliyordu.
    selected = await chrome.tabs.create({url: target.href, active: true});
    await sessionSet(PENDING_COMED_KEY, {
      tabId: selected.id,
      url: target.href,
      createdAt: Date.now(),
    });
  }
  return {
    reused: Boolean(tab),
    tabId: selected.id,
    waitingForLogin: isComedAuthUrl(selected.url),
  };
}

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete" || !isComedUrl(tab.url)) return;
  const pending = await sessionGet(PENDING_COMED_KEY);
  if (!pending || pending.tabId !== tabId) return;
  if (Date.now() - pending.createdAt > 30 * 60 * 1000) {
    await sessionRemove(PENDING_COMED_KEY);
    return;
  }
  if (isComedAuthUrl(tab.url)) return;
  if (!sameComedTarget(tab.url, pending.url)) {
    await chrome.tabs.update(tabId, {url: pending.url, active: true});
    return;
  }
  await sessionRemove(PENDING_COMED_KEY);
});

async function settings() {
  const value = await chrome.storage.local.get(["apiBase", "token", "username"]);
  return {
    apiBase: (value.apiBase || DEFAULT_API).replace(/\/$/, ""),
    token: value.token || "",
    username: value.username || "",
  };
}

async function klinotFetch(path, options = {}) {
  const current = await settings();
  if (!current.token) throw new Error("Klinot köprüsü bağlı değil");
  const response = await fetch(`${current.apiBase}${path}`, {
    ...options,
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${current.token}`,
      ...(options.body ? {"Content-Type": "application/json"} : {}),
      ...(options.headers || {}),
    },
  });
  const payload = await response.json().catch(() => ({}));
  if (response.status === 401) {
    // Klinot oturumu dustu. Kayitli tokeni silmek popup'i otomatik olarak
    // giris ekranina dondurur; aksi halde kullanici "bagli" gorunup her
    // istekte sessizce hata alirdi.
    await chrome.storage.local.remove("token");
    throw new Error("Klinot oturumu sona erdi. Eklentiden tekrar bağlanın.");
  }
  if (!response.ok) throw new Error(payload.detail || payload.error || `HTTP ${response.status}`);
  return payload;
}

/* ---- arka planda hasta kimligi toplama ----
   COMED is listesi satirinda T.C. kimlik numarasi yok; kimlik yalnizca hasta
   kartindaki "Hasta Bilgileri" panelinde yaziyor. Hastanin randevusu bu
   yuzden ancak doktor karti actiginda baglanabiliyordu.

   Burada karti ARKA PLANDA (active:false) aciyoruz: content.js kimligi okuyup
   sunucuya yolluyor, ardindan sekme kendini kapattiriyor. Doktorun ekraninda
   hicbir sey degismiyor, acik sekmesi de bozulmuyor. */
const BACKGROUND_CARD_KEY = "klinotBackgroundCards";
const BACKGROUND_CARD_TTL = 60000;

async function backgroundCards() {
  const kayit = (await sessionGet(BACKGROUND_CARD_KEY)) || {};
  const simdi = Date.now();
  // Bir sekme kapanmadiysa (hata/yonlendirme) kaydi sonsuza kadar tutma.
  for (const [id, item] of Object.entries(kayit)) {
    if (simdi - (item?.createdAt || 0) > BACKGROUND_CARD_TTL) delete kayit[id];
  }
  return kayit;
}

async function openCardInBackground(rawUrl) {
  const target = parsedUrl(rawUrl);
  if (!target || target.hostname !== COMED_HOST) {
    throw new Error("Geçersiz COMED hasta kartı adresi");
  }
  const kayit = await backgroundCards();
  if (Object.keys(kayit).length >= 1) {
    // Ayni anda tek kart: COMED'i de doktorun makinesini de yormayalim.
    return {skipped: true};
  }
  const tab = await chrome.tabs.create({url: target.href, active: false});
  kayit[tab.id] = {url: target.href, createdAt: Date.now()};
  await sessionSet(BACKGROUND_CARD_KEY, kayit);
  // Guvenlik agi: content.js kapatmayi beceremezse sekme asili kalmasin.
  setTimeout(async () => {
    const guncel = await backgroundCards();
    if (guncel[tab.id]) {
      delete guncel[tab.id];
      await sessionSet(BACKGROUND_CARD_KEY, guncel);
      chrome.tabs.remove(tab.id).catch(() => {});
    }
  }, BACKGROUND_CARD_TTL);
  return {opened: true, tabId: tab.id};
}

async function closeBackgroundCard(tabId) {
  const kayit = await backgroundCards();
  if (!kayit[tabId]) return {closed: false};
  delete kayit[tabId];
  await sessionSet(BACKGROUND_CARD_KEY, kayit);
  await chrome.tabs.remove(tabId).catch(() => {});
  return {closed: true};
}

chrome.tabs.onRemoved.addListener(async (tabId) => {
  const kayit = await backgroundCards();
  if (!kayit[tabId]) return;
  delete kayit[tabId];
  await sessionSet(BACKGROUND_CARD_KEY, kayit);
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "klinot-open-comed") {
    openComedTarget(message.url, _sender)
      .then((data) => sendResponse({ok: true, ...data}))
      .catch((error) => sendResponse({ok: false, error: error.message}));
    return true;
  }
  if (message?.type === "klinot-collect-identity") {
    openCardInBackground(message.url)
      .then((data) => sendResponse({ok: true, ...data}))
      .catch((error) => sendResponse({ok: false, error: error.message}));
    return true;
  }
  if (message?.type === "klinot-background-card-role") {
    // content.js soruyor: "ben arka plan kartı mıyım?"
    backgroundCards()
      .then((kayit) => sendResponse({ok: true, background: Boolean(kayit[_sender?.tab?.id])}))
      .catch(() => sendResponse({ok: true, background: false}));
    return true;
  }
  if (message?.type === "klinot-background-card-done") {
    closeBackgroundCard(_sender?.tab?.id)
      .then((data) => sendResponse({ok: true, ...data}))
      .catch((error) => sendResponse({ok: false, error: error.message}));
    return true;
  }
  if (message?.type !== "klinot-request") return false;
  klinotFetch(message.path, message.options)
    .then((data) => sendResponse({ok: true, data}))
    .catch((error) => sendResponse({ok: false, error: error.message}));
  return true;
});
